package com.webmyne.fooddelivery.adapter

import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.address_list.view.*
import kotlinx.android.synthetic.main.item_faq.view.*

class FAQAdapter(
    val context: BaseActivity
): RecyclerView.Adapter<FAQAdapter.AllUserVH>() {
    var rowIndex:Int = -1
    var flag:Int=0
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllUserVH {
        return AllUserVH(
            LayoutInflater.from(context).inflate(
                R.layout.item_faq,
                parent,
                false
            )
        )
    }



    override fun onBindViewHolder(holder:AllUserVH, position: Int) {

   //  holder.itemView.txtaddress.text=useradress.get(position).adressType+"\n"+" ,"+useradress.get(position).address1+"," +useradress.get(position).city+"," +useradress.get(position).country+"," +useradress.get(position).zipcode
        holder.rlFaq.setOnClickListener {
            if (flag==0)
            {
                flag=1
                holder.txtFeqMore.visibility=View.VISIBLE
                holder.imgOpenFeq.setImageResource(R.drawable.ic_icon_colse_faq)
            }
            else if (flag==1)
            {
                flag=0
                holder.txtFeqMore.visibility=View.GONE
                holder.imgOpenFeq.setImageResource(R.drawable.ic_icon_colse_faq)
            }

        }


    }
    override fun getItemCount(): Int {
        return 5

    }
    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {
        val txtFeqMore=view.txtFeqMore
        val imgOpenFeq=view.imgOpenFeq
        val rlFaq=view.rlFaq

    }
}