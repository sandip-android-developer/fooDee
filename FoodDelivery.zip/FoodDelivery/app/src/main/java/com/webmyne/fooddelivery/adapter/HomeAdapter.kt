package com.webmyne.fooddelivery.adapter

import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R

import com.webmyne.fooddelivery.model.HomeDetails
import com.webmyne.fooddelivery.ui.*
import kotlinx.android.synthetic.main.home_item_list.view.*

class HomeAdapter(
    val context: BaseActivity,
    val item: ArrayList<HomeDetails>,
    var onItemCount: onitemCount
) : RecyclerView.Adapter<HomeAdapter.ViewVH>() {
 var CItem:Int=0
    var Count:Int=0

    override fun onCreateViewHolder(parent: ViewGroup, position: Int):ViewVH {
        return ViewVH(LayoutInflater.from(context).inflate(R.layout.home_item_list, parent, false))
    }
    override fun onBindViewHolder(holder: ViewVH, position: Int) {
        var CountItem:Int=0

    //onItemCount.onitemcount(Count)
          holder.itemView.imgHomeChefImage.setOnClickListener {
           AboutChefActivity.launchActivity(context)

        }

         holder.itemView.imgHomeItemLeftArrow.setOnClickListener(object : View.OnClickListener {
             override fun onClick(v: View?) {

                     if (CountItem > 0) {

                         CountItem--
                         Count--
                         holder.itemView.txtHomeNumberOfItem.text = "$CountItem"
                        // Count="$CountItem".toInt()
                         onItemCount.onitemcount(Count)
                         Log.e("count","count"+Count)
                     }


             }

         })

        holder.itemView.imgHomeItemRightArrow.setOnClickListener(object : View.OnClickListener {
             override fun onClick(v: View?) {
                 CountItem++
                 Count++
                 holder.itemView.txtHomeNumberOfItem.text = "$CountItem"
                // Count="$CountItem".toInt()
                 onItemCount.onitemcount(Count)

                 Log.e("count","count"+Count)
        }

         })

         holder.itemView.imgHomeItemImage_fav.setOnClickListener {
                 ChefDetailsActivity.launchActivity(context)

         }

    }

    override fun getItemCount(): Int {
     return item.size
    }


    class ViewVH (view: View) : RecyclerView.ViewHolder(view) {
        var imgHomeItemImage_fav=view.imgHomeItemImage_fav
    }
    interface onitemCount{
        fun onitemcount(count:Int)
    }
}
