package com.webmyne.fooddelivery.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.content.ContextCompat
import android.util.Base64
import android.util.Log
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.custome.MDToast
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_edit_profile.*
import java.io.ByteArrayOutputStream
import java.io.IOException

class EditProfileActivity: BaseActivity() {
    var PERMISSION_CODE = 1001
    private val GALLERY = 1
    private val CAMERA = 2
    var flag: Boolean = false
    var path: String = ""
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, EditProfileActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        initView()
        actionListner()


    }

    private fun actionListner() {
        txtSaveEditProfile.setOnClickListener {
            MyProfileActivity.launchActivity(this)
        }
        txtXCancelEditProfile.setOnClickListener {
            onBackPressed()
        }
        llBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun initView() {
        imguserEdit.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_DENIED
                ) {
                    val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    requestPermissions(permission, PERMISSION_CODE)
                } else {
                    showPictureDialog()
                }
            } else {
                showPictureDialog()
            }

        }
    }

    private fun showPictureDialog() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle("Select Action")
        val pictureDialogItems = arrayOf("Select photo from gallery", "Capture photo from camera")
        pictureDialog.setItems(
            pictureDialogItems
        ) { dialog, which ->
            when (which) {
                0 -> choosePhotoFromGallary()
                1 -> takePhotoFromCamera()
            }
        }
        pictureDialog.show()
    }

    private fun takePhotoFromCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA)
    }

    private fun choosePhotoFromGallary() {
        val galleryIntent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        startActivityForResult(galleryIntent, GALLERY)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            PERMISSION_CODE -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("Meassage", "Message")
                    showPictureDialog()
                } else {
                    Log.e("Meassage", "Message")
                    Functions.showToast(this, "Permission Denied...", MDToast.TYPE_INFO)
                }
                return
            }
            else -> {

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY) {
            if (data != null) {
                val contentURI = data!!.data
                try {
                    var bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, contentURI)
                    path = saveImage(bitmap)
                    Log.e("Path", "Path" + path)
                    bitmap = getCircularBitmap(bitmap)
                    flag = true
                    imguserEdit!!.setImageBitmap(bitmap)

                } catch (e: IOException) {
                    e.printStackTrace()
                }

            }

        } else if (requestCode == CAMERA) {
            if (data != null) {
                try {
                    var thumbnail = data!!.extras!!.get("data") as Bitmap
                    thumbnail = getCircularBitmap(thumbnail) as Bitmap
                    flag = true
                    imguserEdit!!.setImageBitmap(thumbnail)
                    path = saveImage(thumbnail)
                    Log.e("Path", "Path" + path)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        } else {

        }
    }

    private fun getCircularBitmap(bitmap: Bitmap): Bitmap {
        var squareBitmapWidth = Math.min(bitmap!!.getWidth(), bitmap!!.getHeight())
        val dstBitmap = Bitmap.createBitmap(
            squareBitmapWidth, // Width
            squareBitmapWidth, // Height
            Bitmap.Config.ARGB_8888 // Config
        )
        val canvas = Canvas(dstBitmap)

        val paint = Paint()
        paint.setAntiAlias(true)
        val rect = Rect(0, 0, squareBitmapWidth, squareBitmapWidth)
        var rectF = RectF(rect);
        canvas.drawOval(rectF, paint);
        paint.setXfermode(PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint)
        bitmap.recycle();
        return dstBitmap;
    }

    private fun saveImage(myBitmap: Bitmap?): String {
        val bytes = ByteArrayOutputStream()
        myBitmap!!.compress(Bitmap.CompressFormat.JPEG, 30, bytes)
        val b = bytes.toByteArray()
        return Base64.encodeToString(b, Base64.DEFAULT)

    }

}


