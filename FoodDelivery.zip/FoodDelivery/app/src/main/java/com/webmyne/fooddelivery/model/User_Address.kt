package com.webmyne.fooddelivery.model

open  class User_Address {
     var userid: Int=0
     var adressType: String=""
     var address1: String=""
     var city: String=""
     var state: String=""
     var country: String=""
     var zipcode:String =""
}
