package com.webmyne.fooddelivery.model.ResponsPojo

open class GetCountryResponse{
    var result: List<Result> = ArrayList()
}
