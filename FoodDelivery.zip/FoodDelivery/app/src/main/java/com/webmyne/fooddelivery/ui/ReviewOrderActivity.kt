package com.webmyne.fooddelivery.ui

import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_review_order.*

class ReviewOrderActivity: BaseActivity() {
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, ReviewOrderActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_order)
        initview()
        actionListner()


    }

    private fun actionListner() {
        imgReviewOrder.setOnClickListener {
            onBackPressed()
        }
    }

    private fun initview() {

    }

}