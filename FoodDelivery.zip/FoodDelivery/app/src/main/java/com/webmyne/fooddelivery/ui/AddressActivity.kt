package com.webmyne.fooddelivery.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Spinner
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.GetCityAdapter
import com.webmyne.fooddelivery.adapter.GetCountryAdapter
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import com.webmyne.fooddelivery.model.ResponsPojo.GetCountryResponse
import com.webmyne.fooddelivery.model.ResponsPojo.GetStateResponse
import com.webmyne.fooddelivery.model.ResponsPojo.Result
import com.webmyne.fooddelivery.model.ResponsPojo.ResultX
import com.webmyne.fooddelivery.model.RetroFitService
import kotlinx.android.synthetic.main.activity_address.*
import kotlinx.android.synthetic.main.activity_city.spinerCity
import kotlinx.android.synthetic.main.activity_city.spinerCountry
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AddressActivity: BaseActivity() {
   var countryAdapter: GetCountryAdapter? = null
    var countryList: List<Result> = ArrayList()
     var cityAdapter: GetCityAdapter? = null
    var stateList: List<ResultX> = ArrayList()
    var countryId:String=""
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, AddressActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address)
        initview()
        actionListner()
        stateListApi()
    }

    private fun stateListApi() {
        if (!countryId.equals("")) {

            if (!Functions.isConnected(this)) {
                // Functions.showToast(this, getString(R.string.internet_connection), MDToast.TYPE_INFO)
            } else {

                RetroFitService.getService().getState("getStates", countryId)
                    .enqueue(object : Callback<GetStateResponse> {
                        override fun onFailure(call: Call<GetStateResponse>, t: Throwable) {
                            hideProgressDialog()
                            Log.e("Error", t.localizedMessage)

                        }

                        override fun onResponse(call: Call<GetStateResponse>, response: Response<GetStateResponse>) {
                            if (response.body() != null) {
                                Log.e("Response", "Response" + response.body()!!.result)

                                stateList = response.body()!!.result as List<ResultX>
                                val visitType = ResultX()
                                visitType.name = "Choose State"
                                visitType.id = "0"
                                (stateList as MutableList<ResultX>).add(0, visitType)
                                cityAdapter!!.setStateList(stateList)
                            }
                        }

                    })


            }
        }
    }

    private fun actionListner() {
        txtGetStarted.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }

        Log.e("Click","Click")

            if (!Functions.isConnected(this)) {
                // Functions.showToast(this, getString(R.string.internet_connection), MDToast.TYPE_INFO)
            } else {

                RetroFitService.getService().getCountry("getCountries").enqueue(responseCallback)
            }
    }
    val responseCallback = object : Callback<GetCountryResponse> {

        override fun onResponse(
            call: Call<GetCountryResponse>,
            response: Response<GetCountryResponse>
        ) {
            if (response.body() != null) {
                Log.e("Response", "Response" + response.body()!!.result)
                countryList = response.body()!!.result as List<Result>
                val visitType = Result()
                visitType.name = "Choose Country"
                visitType.id = "0"
                (countryList as MutableList<Result>).add(0, visitType)
                countryAdapter!!.setCountryList(countryList)
            }
        }

        override fun onFailure(call: Call<GetCountryResponse>, t: Throwable) {
            Log.e("Error", t.localizedMessage)
        }
    }



    private fun initview() {

       /* val locale = Locale.getAvailableLocales()
        val countries = ArrayList<String>()
        var allcountry: String=""
        countries.add(0,"Choose country")
        for (loc in locale) {

            allcountry = loc.getDisplayCountry()
            if (allcountry.length > 0 && !countries.contains(allcountry)) {
                countries.add(allcountry)
            }
        }
        Collections.sort(countries, String.CASE_INSENSITIVE_ORDER)

        val state=ArrayList<String>()
        var allState:String=""
        for (loc in locale)
        {
            // allState=loc.
        }
        var spinner: Spinner =spinerCountry
        var cityspinner: Spinner =spinerCity
        var Countryname:String
        var stateName:String
        //val country = arrayOf("Country", "Australia", "Brazil", "China", "France", "Germany", "India", "Ireland", "Italy", "Mexico", "Poland")
        var city = arrayOf("City","Vadodara", "Mumbai", "Delhi", "Banglore", "Ranchi", "Surat", "Ahemdabad", "Chennai", "kolkata", "Pune", "Bubhneswar")
      //  spinner.adapter= ArrayAdapter(this,android.R.layout.simple_spinner_item, countries)*/
        var spinner: Spinner =spinerCountry
        var cityspinner: Spinner =spinerCity

        countryAdapter =
            GetCountryAdapter(this, R.layout.spinner_item, R.id.txtItem, countryList,object :GetCountryAdapter.oncountryselected{
                override fun oncountryselected(ID: String) {
                    countryId=ID
                    Log.e("Id","Id"+countryId)
                    stateListApi()
                }

            })
        spinner!!.setAdapter(countryAdapter)
        spinner!!.setSelection(0)

        cityAdapter =
            GetCityAdapter(this, R.layout.spinner_item, R.id.txtItem, stateList,object :GetCityAdapter.oncityselected{
                override fun oncityselected(name: String) {
                    PrefUtils.setCityname(this@AddressActivity,name)
                }

            })
        cityspinner!!.setAdapter(cityAdapter)
        cityspinner!!.setSelection(0)

    }
}