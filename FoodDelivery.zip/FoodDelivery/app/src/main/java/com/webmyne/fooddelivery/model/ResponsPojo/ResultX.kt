package com.webmyne.fooddelivery.model.ResponsPojo

open class ResultX{
    var id: String=""
    var name: String=""
}

