package com.webmyne.fooddelivery.ui

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.LinearLayoutManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.MyAddressAdapter
import com.webmyne.fooddelivery.adapter.MyFavoriteAdapter
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_help.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_my_profile.*

class MyProfileActivity : BaseActivity() {
    private lateinit var mDrawerLayout: DrawerLayout
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()


    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, MyProfileActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        layoutMyProfile.visibility= View.VISIBLE
        initview()
        actionListner()

    }

    private fun actionListner() {
        rvMyProfileAddress.layoutManager=LinearLayoutManager(this)
        rvMyProfileAddress.adapter=MyAddressAdapter(this)

    }

    private fun initview() {
      rvFavorite_MyProfile.layoutManager=LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        rvFavorite_MyProfile.adapter=MyFavoriteAdapter(this)

        mDrawerLayout = findViewById(R.id.drawer_layout)
        imgMyProfileMenuIcon.setOnClickListener {
            if(!mDrawerLayout.isDrawerOpen(GravityCompat.START)) mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }

        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header= navigationView.getHeaderView(0)

        val headerMyProfile:RelativeLayout=header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder:LinearLayout=header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews:LinearLayout=header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney:LinearLayout=header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                    DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)

                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }
        txtChangePassword.setOnClickListener {
            var changePass=Intent(this,ChangePasswordActivity::class.java)
            startActivity(changePass)
        }
        txtMyAddress.setOnClickListener {
            var editProfile = Intent(this, EditProfileActivity::class.java)
            startActivity(editProfile)
        }

    }
}
