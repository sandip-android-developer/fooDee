package com.webmyne.fooddelivery.model

data class HomeDetails(
    var ItemImage:String,
    var ItemCity:String,
    var ItemName:String
)
