package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R

class ReviewsAdapter(
    val context: Context
) : RecyclerView.Adapter<ReviewsAdapter.ViewVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, position: Int):ViewVH {
        return ViewVH(LayoutInflater.from(context).inflate(R.layout.item_reviews, parent, false))
    }
    override fun onBindViewHolder(holder: ViewVH, position: Int) {

    }

    override fun getItemCount(): Int {
     return 10
    }


    class ViewVH (view: View) : RecyclerView.ViewHolder(view) {

    }
}
