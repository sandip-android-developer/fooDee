package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.MenuItemAdapter
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_menu_item_list.*

class MenuItemListactivity: BaseActivity() {
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, MenuItemListactivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_item_list)
        initview()
        actionListner()
    }

    private fun actionListner() {

    }

    private fun initview() {
        rvMenuItem.layoutManager=LinearLayoutManager(this)
        rvMenuItem.adapter=MenuItemAdapter(this)

    }
}