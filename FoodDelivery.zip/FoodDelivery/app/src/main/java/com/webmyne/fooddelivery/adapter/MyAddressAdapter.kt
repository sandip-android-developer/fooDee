package com.webmyne.fooddelivery.adapter

import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.address_list.view.*

class MyAddressAdapter(
    val context: BaseActivity
): RecyclerView.Adapter<MyAddressAdapter.AllUserVH>() {
    var rowIndex:Int = -1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllUserVH {
        return AllUserVH(
            LayoutInflater.from(context).inflate(
                R.layout.address_list,
                parent,
                false
            )
        )
    }



    override fun onBindViewHolder(holder:AllUserVH, position: Int) {

   //  holder.itemView.txtaddress.text=useradress.get(position).adressType+"\n"+" ,"+useradress.get(position).address1+"," +useradress.get(position).city+"," +useradress.get(position).country+"," +useradress.get(position).zipcode

        holder.itemView.setOnClickListener {

            rowIndex = position
            notifyDataSetChanged()

        }

        if(rowIndex == -1 && position == 0){
            holder.itemView.imgAddressSelected.visibility = View.VISIBLE
        }else{
            if(rowIndex == position) {
                Log.e("Click","Click")
                holder.itemView.imgAddressSelected.visibility = View.VISIBLE
            }else {
                Log.e("Click1","Click1")
                holder.itemView.imgAddressSelected.visibility = View.INVISIBLE
            }
        }
        if (position==4)
        {
            holder.viewMyAddress.visibility=View.GONE
        }
        else
        {
            holder.viewMyAddress.visibility=View.VISIBLE
        }


    }
    override fun getItemCount(): Int {
        return 5

    }
    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {
        val imgAddressSelected=view.imgAddressSelected
        val viewMyAddress=view.viewMyAddress

    }
}