package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.UserDataAdapter
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.model.User
import kotlinx.android.synthetic.main.userlist_recycler.*

class UserListActivity:BaseActivity() {
    var userList:List<User> = ArrayList()
    var db: DatabaseHelper = DatabaseHelper(this)
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, UserListActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.userlist_recycler)
        initview()
        actionListner()



    }

    private fun actionListner() {

    }

    private fun initview() {
        rv_userList.layoutManager=LinearLayoutManager(this)
        rv_userList.adapter=UserDataAdapter(this,userList)
        //var rv=findViewById<RecyclerView>(R.id.rv_userList)
        db= DatabaseHelper(this)
        userList=db.viewUser()
        Log.e("UserList","UserList"+userList)
        if (userList.size>0)
        {
            for (i in 0 until userList.get(0).userPayment.size)
            {
                Log.e("UserList","UserList"+userList.get(0).userPayment.toString())

            }
            rv_userList.adapter=UserDataAdapter(this,userList)
        }
        else{
            txtNoDataFound.visibility=View.VISIBLE
        }

    }

}