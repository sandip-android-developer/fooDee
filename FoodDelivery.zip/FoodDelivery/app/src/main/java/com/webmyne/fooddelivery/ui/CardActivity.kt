package com.webmyne.fooddelivery.ui

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.CardAdapter
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_card.*

class CardActivity: BaseActivity() {
    val db: DatabaseHelper = DatabaseHelper(this)
    var list:List<String> = ArrayList()
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, CardActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card)
        initview()
        actionListner()


    }

    private fun actionListner() {
        val intent = getIntent();
        /*if (db.viewUser().get(0).userPayment!=null)
        {
            list=db.viewUser().get(0).userPaymentIfo
            var list:List<String> = ArrayList()
            list=intent.getStringArrayListExtra("cardDetails")
        }
       */
        imgAddCard.setOnClickListener {
            var addACard=Intent(this,SaveCardActivity::class.java)
            startActivity(addACard)
        }
        imgbackModakMoney.setOnClickListener {
            var backCard=Intent(this,DashboardActivity::class.java)
            startActivity(backCard)

        }
        rvCardPayment.layoutManager=LinearLayoutManager(this)
        rvCardPayment.adapter=CardAdapter(this)
    }

    private fun initview() {

    }

}