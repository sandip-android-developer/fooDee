package com.webmyne.fooddelivery.model.ResponsPojo

open class Result{
    var id: String=""
    var name: String=""
}