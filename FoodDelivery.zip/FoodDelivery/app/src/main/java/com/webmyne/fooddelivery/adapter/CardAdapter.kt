package com.webmyne.fooddelivery.adapter
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import com.webmyne.fooddelivery.ui.ReviewOrderActivity
import java.util.ArrayList

class CardAdapter(val context: BaseActivity) :RecyclerView.Adapter<CardAdapter.cardVH>(){

    override fun onBindViewHolder(holder: cardVH, position: Int) {
        holder.itemView.setOnClickListener {
            ReviewOrderActivity.launchActivity(context)

        }

    }

    override fun getItemCount(): Int {
       return 10
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): cardVH {
        return cardVH(LayoutInflater.from(parent.context).inflate(R.layout.item_card_details, parent, false))
    }

    class cardVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView
        var itemTitle: TextView

        init {
            itemImage = itemView.findViewById(R.id.imgCardType)
            itemTitle = itemView.findViewById(R.id.txtCardNumber)
        }
    }

}

