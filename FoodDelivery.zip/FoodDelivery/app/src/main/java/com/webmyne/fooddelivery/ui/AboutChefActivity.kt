package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.webmyne.fooddelivery.R
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.custome.AddRateDialog
import com.webmyne.fooddelivery.custome.FilterDialog
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import com.yarolegovich.slidingrootnav.SlidingRootNav
import kotlinx.android.synthetic.main.activity_about_chef.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.cheft_details.*
import kotlinx.android.synthetic.main.toolbar_about_chef.*

class AboutChefActivity: BaseActivity(),OnMapReadyCallback{
    private lateinit var mMap: GoogleMap
    private lateinit var mDrawerLayout: DrawerLayout
    private var toolbar: Toolbar? = null
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()
    private var slidingRootNav: SlidingRootNav? = null
    var latLng: LatLng = LatLng(0.00, 0.00)

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, AboutChefActivity::class.java, true, false)
            }
        }
    }
    override fun onMapReady(googleMap: GoogleMap?) {
        mMap = googleMap!!
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        layoutaboutChef.visibility= View.VISIBLE
        initview()
        actionListner()

    }

    private fun initview() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)


        mDrawerLayout = findViewById(R.id.drawer_layout)

        imgIconaboutMenu.setOnClickListener {
            Log.e("Click","click")
            if (!mDrawerLayout.isDrawerOpen(GravityCompat.START)) mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header = navigationView.getHeaderView(0)

        val headerMyProfile: RelativeLayout = header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder: LinearLayout = header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews: LinearLayout = header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney: LinearLayout = header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                    DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)

                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }



    }

    private fun actionListner() {
        txtCityAcboutChef.text= PrefUtils.getCityname(this)
        btnReadMore.setOnClickListener {
            btnReadMore.visibility = View.INVISIBLE
            txtReadMore.visibility = View.VISIBLE
            btnReadLess.visibility = View.VISIBLE

        }
        btnReadLess.setOnClickListener {
            btnReadLess.visibility = View.INVISIBLE
            txtReadMore.visibility = View.GONE
            btnReadMore.visibility = View.VISIBLE

        }
        layoutReviewChef.setOnClickListener {
            loadButtonUiAbout(1)
        }
        layoutShareChef.setOnClickListener {
            loadButtonUiAbout(2)
        }
        layoutRate.setOnClickListener {
            loadButtonUiAbout(3)
            AddRateDialog(this)
        }
        layoutMenu.setOnClickListener {
            loadButtonUiAbout(4)
        }
        txtCityAcboutChef.setOnClickListener {
            MyAddressActivity.launchActivity(this)
        }
        imgiconGps.setOnClickListener {
            AddressActivity.launchActivity(this)
        }
        imgFilterAboutChef.setOnClickListener {
           FilterDialog(this)
        }

    }




    private fun loadButtonUiAbout(position: Int) {
        when (position) {
            1 -> {
                txtReviewsChefName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                imgReviewsChef.setImageResource(R.drawable.icon_review_selected)
                layoutShareChef.setOnClickListener {
                    imgShare.setImageResource(R.drawable.icon_share_selected)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtShareName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
                layoutRate.setOnClickListener {
                    imgRate.setImageResource(R.drawable.icon_rate_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    AddRateDialog(this)

                }
                layoutMenu.setOnClickListener {
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
            }
            2 -> {
                imgShare.setImageResource(R.drawable.icon_share_selected)
                txtShareName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                layoutReviewChef.setOnClickListener {
                    imgReviewsChef.setImageResource(R.drawable.icon_review_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
                layoutRate.setOnClickListener {

                    imgRate.setImageResource(R.drawable.icon_rate_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    AddRateDialog(this)
                }
                layoutMenu.setOnClickListener {
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))
                }
            }
            3 -> {
                AddRateDialog(this)
                imgRate.setImageResource(R.drawable.icon_rate_selected)
                txtRateName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                layoutReviewChef.setOnClickListener {
                    imgReviewsChef.setImageResource(R.drawable.icon_review_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
                layoutShareChef.setOnClickListener {
                    imgShare.setImageResource(R.drawable.icon_share_selected)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
                layoutMenu.setOnClickListener {
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
            }
            4 -> {
                imgMenu.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                txtMenuName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                layoutShareChef.setOnClickListener {
                    imgShare.setImageResource(R.drawable.icon_share_selected)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
                layoutRate.setOnClickListener {
                    imgRate.setImageResource(R.drawable.icon_rate_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgReviewsChef.setImageResource(R.drawable.icon_review)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.black))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    AddRateDialog(this)

                }
                layoutReviewChef.setOnClickListener {
                    imgReviewsChef.setImageResource(R.drawable.icon_review_selected)
                    imgShare.setImageResource(R.drawable.icon_share)
                    imgMenu.setImageResource(R.drawable.icon_menu_chef_detail)
                    imgRate.setImageResource(R.drawable.icon_rate)
                    txtShareName.setTextColor(getResources().getColor(R.color.black))
                    txtReviewsChefName.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtMenuName.setTextColor(getResources().getColor(R.color.black))
                    txtRateName.setTextColor(getResources().getColor(R.color.black))

                }
            }
        }

    }
}