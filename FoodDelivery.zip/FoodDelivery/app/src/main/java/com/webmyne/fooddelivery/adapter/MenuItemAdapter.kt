package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RatingBar
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.PrefUtils
import kotlinx.android.synthetic.main.item_chef_reviews.view.*

class MenuItemAdapter(
    val context: Context
) : RecyclerView.Adapter<MenuItemAdapter.ViewVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, position: Int):ViewVH {
        return ViewVH(LayoutInflater.from(context).inflate(R.layout.menu_item_list, parent, false))
    }
    override fun onBindViewHolder(holder: ViewVH, position: Int) {


    }

    override fun getItemCount(): Int {
     return 10
    }


    class ViewVH (view: View) : RecyclerView.ViewHolder(view) {

    }
}
