package com.webmyne.fooddelivery.model

import com.webmyne.fooddelivery.model.ResponsPojo.GetCountryResponse
import com.webmyne.fooddelivery.model.ResponsPojo.GetStateResponse
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface Api {
     @GET("api.php")
    fun getCountry(@Query("type") country:String): Call<GetCountryResponse>

    @GET("api.php")
    fun getState(@Query("type") country:String,@Query("countryId") countryId:String): Call<GetStateResponse>
}


