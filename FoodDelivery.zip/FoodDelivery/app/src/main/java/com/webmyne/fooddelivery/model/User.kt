package com.webmyne.fooddelivery.model

data class User (
     var userid: Int,
     var username: String,
     var useremail: String,
     var usermobile: String,
     var userpassword: String,
     var useradress: List<User_Address> = ArrayList(),
     var userPayment: List<User_PaymentInfo> = ArrayList(),
     var userImage: String
)