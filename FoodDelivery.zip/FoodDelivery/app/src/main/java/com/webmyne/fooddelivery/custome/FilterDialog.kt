package com.webmyne.fooddelivery.custome

import android.app.DatePickerDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.StrictMode
import android.util.DisplayMetrics
import android.view.*
import com.webmyne.fooddelivery.ui.BaseActivity
import android.view.Gravity
import android.widget.CompoundButton
import android.widget.RadioGroup
import android.widget.SeekBar
import com.webmyne.fooddelivery.R
import kotlinx.android.synthetic.main.dialog_filter.*
import java.util.*




class FilterDialog(val context: BaseActivity) : Dialog(context) {
    var view: View = View(context)
    var closeIconTime=0
    var closeIconPrice=0
    var closeIconFood=0
    var closeIconDistance=0
    private var cal: Calendar? = null
    private var todate: Date? = null
    private var selectedDate: Date? = null
    init {
        init()
    }

    private fun init() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        view = LayoutInflater.from(context).inflate(R.layout.dialog_filter, null)
        setContentView(view)
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        val displayMetrics = DisplayMetrics()
        context.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(window!!.attributes)
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.TOP or Gravity.RIGHT
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window!!.attributes = lp
        window!!.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )
        window!!.setFlags(
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        )

        val policy: StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        show()
        imgFilterBack.setOnClickListener {
            dismiss()
        }
        btnFilterApply.setOnClickListener {
            onBackPressed()
        }
        actionListner()



    }

    private fun actionListner() {
       rlTime.setOnClickListener {
            if (closeIconTime==0)
            {
                imgTime.setImageResource(R.drawable.ic_menu_icon_close)
                llTime.visibility=View.VISIBLE
                closeIconTime=1
            }
            else
            {
                closeIconTime=0
                imgTime.setImageResource(R.drawable.ic_menu_icon_open)
                llTime.visibility=View.GONE
            }


        }
       rlprice.setOnClickListener {
            if (closeIconPrice==0)
            {

                imgPriceFilter.setImageResource(R.drawable.ic_menu_icon_close)
                llPrice.visibility=View.VISIBLE
                closeIconPrice=1
            }
            else
            {
                closeIconPrice=0
                imgPriceFilter.setImageResource(R.drawable.ic_menu_icon_open)
                llPrice.visibility=View.GONE
            }
        }
        cal = Calendar.getInstance()
        todate = cal!!.getTime()
        rlDate.setOnClickListener {
            DateDialog()
        }
       rlFoodType.setOnClickListener {
            if (closeIconFood==0)
            {
                imgfoodType.setImageResource(R.drawable.ic_menu_icon_close)
                llFoodType.visibility=View.VISIBLE
                closeIconFood=1
            }
            else
            {
                closeIconFood=0
                imgfoodType.setImageResource(R.drawable.ic_menu_icon_open)
                llFoodType.visibility=View.GONE
            }
         /* checkbox1.setOnCheckedChangeListener(object :CompoundButton.OnCheckedChangeListener{
              override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
                  checkbox2.isChecked=false
              }

          })
            checkbox2.setOnCheckedChangeListener(object :CompoundButton.OnCheckedChangeListener{
                override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
                    checkbox1.isChecked=false
                }

            })*/
        }
        rlDistance.setOnClickListener {
            if (closeIconDistance==0)
            {
                imgDistanceFilter.setImageResource(R.drawable.ic_menu_icon_close)
                llDistance.visibility=View.VISIBLE
                closeIconDistance=1
                Distance()
            }
            else
            {
                closeIconDistance=0
                imgDistanceFilter.setImageResource(R.drawable.ic_menu_icon_open)
                llDistance.visibility=View.GONE
            }
        }


    }

    private fun Distance() {
        seekbar.setOnSeekBarChangeListener(object :SeekBar.OnSeekBarChangeListener{
            var pval = 0
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {

                pval = progress;
                txtProgressSeekbar.text=pval.toString()+" miles"
                txtProgressSeekbar.setTextColor(context.getResources().getColor(R.color.colorsplacebackground))
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {


            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

            }

        })
    }

    private fun DateDialog() {
        val day = cal!!.get(Calendar.DAY_OF_MONTH)
        val month = cal!!.get(Calendar.MONTH)
        val year = cal!!.get(Calendar.YEAR)

        val listener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            var monthOfYear = monthOfYear
            monthOfYear = monthOfYear + 1
            txtDateSelected.setText(" : "+String.format("%02d", dayOfMonth) + "/" + String.format("%02d", monthOfYear) + "/" + year)
        }
        val dpDialog = DatePickerDialog(context, listener, year, month - 1, day)
        dpDialog.show()
    }

   /*fun String getCurrentDate()
    {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy")
        val date = Date()
        return dateFormat.format(date)
    }*/
}