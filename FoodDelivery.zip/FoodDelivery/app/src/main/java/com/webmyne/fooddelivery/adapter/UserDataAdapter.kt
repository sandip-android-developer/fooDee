package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.model.User
import kotlinx.android.synthetic.main.register_user.view.*

class UserDataAdapter(val context: Context,val userlist:List<User>): RecyclerView.Adapter<UserDataAdapter.AllUserVH>() {
    var List= mutableListOf<String>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllUserVH {
        return AllUserVH(LayoutInflater.from(context).inflate(R.layout.register_user, parent, false))
    }

    override fun getItemCount(): Int {
        return userlist.size

    }

    override fun onBindViewHolder(holder: AllUserVH, position: Int) {
        holder.itemView.txtName.text="Name: "+userlist.get(position).username
        holder.itemView.txtEmail.text="Enail: "+userlist.get(position).useremail
        holder.itemView.txtMobile.text="Mobile: "+userlist.get(position).usermobile
        holder.itemView.txtpassword.text="Password: "+userlist.get(position).userpassword

            if (userlist.get(position).userPayment.size>0)
            {

                holder.itemView.rvPayment.layoutManager=LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
                holder.itemView.rvPayment.adapter=PaymentAdapter(context,userlist.get(position).userPayment)
            }
        if (userlist.get(position).useradress.size>0)
        {

            holder.itemView.rvAddress.layoutManager=LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
            holder.itemView.rvAddress.adapter=AddressAdapter(context,userlist.get(position).useradress)
        }
    }

    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {

    }
}