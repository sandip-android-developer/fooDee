package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.model.User_PaymentInfo
import kotlinx.android.synthetic.main.item_payment_info.view.*
import kotlinx.android.synthetic.main.register_user.view.*

class PaymentAdapter(val context: Context, val userPayment: List<User_PaymentInfo>
): RecyclerView.Adapter<PaymentAdapter.AllUserVH>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaymentAdapter.AllUserVH {
        return PaymentAdapter.AllUserVH(
            LayoutInflater.from(context).inflate(
                R.layout.item_payment_info,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return userPayment.size

    }

    override fun onBindViewHolder(holder:AllUserVH, position: Int) {
        holder.itemView.txtCardType.text="Payment Info ["+" "+"Card Type :"+userPayment.get(position).cardType+","
        holder.itemView.txtCardNumber.text="Card Number:"+userPayment.get(position).cardNumber+","
        holder.itemView.txtHolderName.text="Holder Name :"+userPayment.get(position).holderName+","
        holder.itemView.txtExpDate.text="Expiry Date :"+userPayment.get(position).cardexpiryMonth+"/"+userPayment.get(position).cardExpiryYear+"]"

    }

    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {

    }
}