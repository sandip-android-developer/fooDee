package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.model.User
import com.webmyne.fooddelivery.model.User_Address
import com.webmyne.fooddelivery.model.User_PaymentInfo
import kotlinx.android.synthetic.main.activity_savecard.*


class SaveCardActivity: BaseActivity(){
    val db: DatabaseHelper = DatabaseHelper(this)
     var cardtype:String=""
    var cardmonth:String=""
    var cardyear:String=""
    var cardType = arrayOf("Master", "Visa", "Rupay","Phone Pay", "Cash", "Apple Pay","Google Pay")
    var month = arrayOf(" 1 jan","2 fab", "3 march", "4 april", "5 may", "6 jun", "7 july", "8 aug", "9 sept", "10 oct", "11 Nov", "12 Dec")
    var Year = arrayOf("2018","2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029")
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, SaveCardActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_savecard)
        initview()
        actionView()


    }

    private fun actionView() {
        imgPaymentBackIcon.setOnClickListener {
           CardActivity.launchActivity(this)
        }

        val spinnercard: Spinner =spinerCardType
        val spinnerYear: Spinner =spinnerYear
        val spinnerMonth: Spinner =spinerMonth


        spinnercard.adapter=  ArrayAdapter(this,android.R.layout.simple_spinner_item,cardType)
        spinnerMonth.adapter= ArrayAdapter(this,android.R.layout.simple_spinner_item,month)
        spinnerYear.adapter= ArrayAdapter(this,android.R.layout.simple_spinner_item,Year)

        cardtype = spinnercard.getSelectedItem().toString()
        cardmonth = spinnerMonth.getSelectedItem().toString()
        cardyear = spinnerYear.getSelectedItem().toString()

    }


    private fun initview() {
        txtSaveCard.setOnClickListener {
            if (!Functions.isConnected(this))
            {
                Toast.makeText(this,getString(R.string.internet_connection),Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            else{
                var list:List<String> = ArrayList()
                var List = ArrayList<String>()
              /*  List.add(cardtype)
                List.add(edtCardnumber.text.toString().trim())
                List.add(cardmonth)
                List.add(cardyear)
                List.add(edtCVV.text.toString().trim())
                List.add(edtZipCode.text.toString().trim())*/
                var userId=0
                var username:String=""
                var useremail:String=""
                var mobile:String=""
                var userpassword:String=""
               /* var list1:List<User> = ArrayList()
                list1=db.viewUser()
                userId=list1.get(0).userid
                username=list1.get(0).username
                useremail=list1.get(0).useremail
                mobile=list1.get(0).usermobile
                userpassword=list1.get(0).userpassword
*/
                var useraddress:List<User_Address>
                var addressId: Int=0
                var adressType: String=""
                var address1: String=""
                var city: String=""
                var state: String=""
                var country: String=""
                var zipcode: String=""

                var userPaymentinfo=User_PaymentInfo()
                var paymentId: Int=0
                var cardType: String=cardtype
                var holderName=edtHolderName.text.toString().trim()
                var cardexpiryMonth: String=cardmonth
                var cardExpiryYear: String=cardyear
                var cardNumber: String=edtCardnumber.text.toString().trim()
               // val address=User_Address(addressId,adressType,address1,city,state,country,zipcode)
                var up=ArrayList<User_PaymentInfo>()
               userPaymentinfo!!.userid=0
                userPaymentinfo!!.cardType=cardtype
                userPaymentinfo!!.holderName=edtHolderName.text.toString().trim()
                userPaymentinfo!!.cardexpiryMonth=cardmonth
                userPaymentinfo!!.cardExpiryYear=cardyear
                userPaymentinfo!!.cardNumber=edtCardnumber.text.toString().trim()



               // val paymentinfo=User_PaymentInfo(paymentId,cardType,holderName,cardexpiryMonth,cardExpiryYear,cardNumber)

                //db.addUser(User(userId, username, useremail, mobile, userpassword,address,paymentinfo))
               // db.addAddress(useremail,paymentinfo)
                db.addPaymentInfo(userId,userPaymentinfo)
                Log.e("List","list"+List)
                CardActivity.launchActivity(this)

            }

        }
    }

}


