package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.model.User
import com.webmyne.fooddelivery.model.User_Address
import com.webmyne.fooddelivery.model.User_PaymentInfo
import kotlinx.android.synthetic.main.activity_signup.*

class SignupActivity: BaseActivity() {
    val db:DatabaseHelper= DatabaseHelper(this)
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, SignupActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        initview()
        actionListner()

    }

    private fun actionListner() {
        txtAlreayAMemeber.setOnClickListener {
            LoginActivity.launchActivity(this)
        }

    }

    private fun initview() {
        textRegister.setOnClickListener {
            bundle.putString(FirebaseAnalytics.Param.SIGN_UP_METHOD, "Signed_up_Android")
            mFirebaseAnalytics?.logEvent(FirebaseAnalytics.Event.SIGN_UP, bundle)
            if (edtUserName.text.toString().trim().length == 0) {
                edtUserName.setError("Please Enter UserName")
                return@setOnClickListener
            }
            if (edtEmail.text.toString().trim().length == 0) {
                edtEmail.setError("Please Enter Email")
                return@setOnClickListener
            }
            if (!Functions.emailValidation(edtEmail.text.toString().trim())) {
                edtEmail.setError("Please Enter Valid Email")
                return@setOnClickListener
            }
            if (db.checkUser(edtEmail.text.toString().trim()))
            {
                edtEmail.setError("This Email is already Exist")
                return@setOnClickListener
            }
            if (edtMobile.text.toString().trim().length == 0) {
                edtMobile.setError("Please Enter Mobile Number")
                return@setOnClickListener
            }
            if (edtMobile.text.toString().trim().length != 10) {
                edtMobile.setError("Please Enter 10 digit Mobile Number")
                return@setOnClickListener
            }
            if (edtPass.text.toString().trim().length == 0) {
                edtPass.setError("Please Enter Password")
                return@setOnClickListener
            }
            if (edtCnfPass.text.toString().trim().length == 0) {
                edtCnfPass.setError("Please Enter Confirm Password")
                return@setOnClickListener
            }
            if (!edtPass.text.toString().trim().equals(edtCnfPass.text.toString().trim())) {
                edtCnfPass.setError("Password And Confirm Password Is Mismatch")
                return@setOnClickListener
            }
            if (!chkIos.isChecked) {
                Toast.makeText(this, getString(R.string.please_accpet_terms_and_condition), Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            } else {

                val username = edtUserName.text.toString()
                val useremail = edtEmail.text.toString()
                val mobile = edtMobile.text.toString()
                val userpassword = edtCnfPass.text.toString()
                Log.e("UserName", "username" + useremail)
                val userId: Int = 0
                val userImage: String = ""
                var userPay=ArrayList<User_PaymentInfo>()
                var userAddress=ArrayList<User_Address>()
                db.addUser(User(userId, username, useremail, mobile, userpassword,userAddress,userPay,userImage))
                Toast.makeText(applicationContext, "Account Successfully Created ", Toast.LENGTH_LONG).show()
                //OTPActivity.launchActivity(this,edtMobile.text.toString())
                DashboardActivity.launchActivity(this)
            }
        }

    }


}