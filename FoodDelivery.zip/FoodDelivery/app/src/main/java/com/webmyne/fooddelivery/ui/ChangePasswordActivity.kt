package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import kotlinx.android.synthetic.main.activity_change_password.*
import kotlinx.android.synthetic.main.activity_signup.*

class ChangePasswordActivity: BaseActivity() {
    val db:DatabaseHelper= DatabaseHelper(this)
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()
    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, ChangePasswordActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)
        initview()
        actionListner()


    }

    private fun actionListner() {
        imgChangePass.setOnClickListener {
           MyProfileActivity.launchActivity(this)
        }
    }

    private fun initview() {
        txtChangePass.setOnClickListener {
            if (edtCurrentPass.text.toString().trim().length == 0) {
                edtCurrentPass.setError("Please Enter Current Password")
                //Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (edtNewPass.text.toString().trim().length == 0) {
                edtNewPass.setError("Please Enter New Password")
                //Toast.makeText(this, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (edtNewCnfPass.text.toString().trim().length == 0) {
                edtNewCnfPass.setError("Please Enter New Password")
                //Toast.makeText(this, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!edtNewCnfPass.text.toString().trim().equals(edtNewPass.text.toString().trim())) {
                edtCnfPass.setError("Password And Confirm Password Is Mismatch")
                // Toast.makeText(this, "Password And Confirm Password Is Mismatch", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            else{

               Log.e("Email","Email"+PrefUtils.getUserEmail(this))
                var pass:String=db.updateUserData(edtNewCnfPass.text.toString().trim(),PrefUtils.getUserEmail(this))
                if (pass.equals(edtCurrentPass.text.toString().trim()))
                {
                    Toast.makeText(this, "Not Change", Toast.LENGTH_SHORT).show()
                }
                else {
                   LoginActivity.launchActivity(this)
                }
            }
        }
    }
}