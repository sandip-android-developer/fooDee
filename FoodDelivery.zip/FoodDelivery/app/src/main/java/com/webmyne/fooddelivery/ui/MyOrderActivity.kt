package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.Functions
import com.yarolegovich.slidingrootnav.SlidingRootNav
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_my_order.*

class MyOrderActivity : BaseActivity(){
    private lateinit var mDrawerLayout: DrawerLayout
    private var slidingRootNav: SlidingRootNav? = null
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, MyOrderActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
          layoutOrder.visibility=View.VISIBLE
        initview()
        actionListner()
        mDrawerLayout = findViewById(R.id.drawer_layout)
        imgOrderMenu.setOnClickListener {
            Log.e("Error1","Error1")
            if(!mDrawerLayout.isDrawerOpen(GravityCompat.START))
                mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }


    }

    private fun actionListner() {
        Log.e("Button2","Button 2")

        btnCurrentOrder.setBackgroundResource(R.color.colorsplacebackground)
        btnCurrentOrder.setTextColor(getResources().getColor(R.color.white))
        btnCurrentOrder.setOnClickListener {
            Log.e("Button1","Button 1")
            loadButtonUiMyOrder(1)
        }
        btnPastOrder.setOnClickListener {
            Log.e("Button2","Button 2")
            btnCurrentOrder.setBackgroundResource(R.color.bgapp)
            loadButtonUiMyOrder(2)

        }
        btnReorder.setOnClickListener {
            ReOrderActivity.launchActivity(this)
        }
    }

    private fun loadButtonUiMyOrder(position: Int) {
            when (position) {
                1 -> {
                    var buttonReviews: TextView =findViewById(R.id.btnPastOrder)
                    var buttonDetails: TextView =findViewById(R.id.btnCurrentOrder)
                    buttonDetails.setBackgroundResource(R.color.colorsplacebackground)
                    buttonReviews.setTextColor(getResources().getColor(R.color.black))
                    buttonDetails.setTextColor(getResources().getColor(R.color.white))
                    buttonReviews.setOnClickListener {
                        buttonReviews.setBackgroundResource(R.color.colorsplacebackground)
                        buttonDetails.resources.getColor(R.color.bgapp)
                        buttonDetails.setBackgroundResource(R.color.bgapp)
                        loadButtonUi(2)

                    }
                }
                2 -> {
                    var buttonReviews: TextView =findViewById(R.id.btnPastOrder)
                    var buttonDetails: TextView =findViewById(R.id.btnCurrentOrder)
                    //  buttonDetails.resources.getColor(R.color.colorAccent)
                    buttonReviews.setBackgroundResource(R.color.colorsplacebackground)
                    buttonDetails.setTextColor(getResources().getColor(R.color.black))
                    buttonReviews.setTextColor(getResources().getColor(R.color.white))
                    // btnReviews.setBackgroundResource(R.color.colorsplacebackground)
                    buttonDetails.setOnClickListener {
                        // buttonDetails.setBackgroundResource(R.color.colorsplacebackground)
                        buttonDetails.setTextColor(getResources().getColor(R.color.white))
                        buttonReviews.setBackgroundResource(R.color.bgapp)
                        buttonReviews.setTextColor(getResources().getColor(R.color.black))
                        buttonDetails.setBackgroundResource(R.color.colorsplacebackground)
                        loadButtonUi(1)

                    }
                }
            }

    }


    private fun initview() {
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header= navigationView.getHeaderView(0)

        val headerMyProfile:RelativeLayout=header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder:LinearLayout=header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews:LinearLayout=header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney:LinearLayout=header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                   DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)
                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }
    }
}
