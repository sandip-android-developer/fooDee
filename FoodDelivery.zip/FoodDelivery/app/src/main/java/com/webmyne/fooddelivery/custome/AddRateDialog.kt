package com.webmyne.fooddelivery.custome

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.StrictMode
import android.util.Base64
import android.util.DisplayMetrics
import android.view.*
import com.bumptech.glide.Glide.init
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.activity_dashbord.*
import kotlinx.android.synthetic.main.dialog_add_reviews.*

class AddRateDialog(val context: BaseActivity) : Dialog(context) {
    var view: View = View(context)
    init {
        init()
    }

    private fun init() {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        view = LayoutInflater.from(context).inflate(R.layout.dialog_add_reviews, null)
        setContentView(view)
        setCanceledOnTouchOutside(true)
        setCancelable(true)
        val displayMetrics = DisplayMetrics()
        context.windowManager.defaultDisplay.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(window!!.attributes)
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window!!.attributes = lp
        window!!.setFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )
        window!!.setFlags(
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        )

        val policy: StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        show()
        btnAddRating.setOnClickListener {
            dismiss()
        }
    }
}