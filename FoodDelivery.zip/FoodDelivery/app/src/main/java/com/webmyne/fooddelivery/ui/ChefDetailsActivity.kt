package com.webmyne.fooddelivery.ui

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.app.ActivityCompat
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.common.GooglePlayServicesRepairableException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.location.places.ui.PlacePicker
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.custome.AddRateDialog
import com.webmyne.fooddelivery.custome.FilterDialog
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import kotlinx.android.synthetic.main.activity_chef_details.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.toolbar_chef_details.*
import kotlinx.android.synthetic.main.toolbar_chef_details.imgiconGps
import java.io.IOException

class ChefDetailsActivity : BaseActivity(),OnMapReadyCallback,GoogleMap.OnMarkerClickListener {
    private lateinit var mDrawerLayout: DrawerLayout
    private var toolbar: Toolbar? = null
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        private const val REQUEST_CHECK_SETTINGS = 2
        private const val PLACE_PICKER_REQUEST = 3
        fun launchActivity(activity: BaseActivity) {
            if (activity != null) {
                Functions.fireIntent(activity, ChefDetailsActivity::class.java, true, false)
            }
        }
    }

    private lateinit var lastLocation: Location
    private lateinit var mMap: GoogleMap
    var latLng: LatLng = LatLng(0.00, 0.00)
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    // 2
    private lateinit var locationRequest: LocationRequest
    private var locationUpdateState = false
    override fun onMarkerClick(p0: Marker?): Boolean {
        mMap.getUiSettings().setZoomControlsEnabled(true)
        mMap.setOnMarkerClickListener(this)
        return false
    }

    override fun onMapReady(googleMap: GoogleMap?) {

        mMap = googleMap!!
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerClickListener(this)

        setUpMap()
        /*val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 12.0f))*/
    }

    private fun setUpMap() {
        setMyLocationEnabled()
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }

        mMap.isMyLocationEnabled = true
        fusedLocationClient.lastLocation.addOnSuccessListener(this) { location ->
            if (location != null) {
                lastLocation = location
                val currentLatLng = LatLng(location.latitude, location.longitude)
                placeMarkerOnMap(currentLatLng)
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f))
            }
        }
    }

    private fun setMyLocationEnabled() {
        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
    }

    private fun placeMarkerOnMap(currentLatLng: LatLng) {
        val markerOptions = MarkerOptions().position(currentLatLng)
        val titleStr = getAddress(currentLatLng)  // add these two lines
        markerOptions.title(titleStr)
        mMap.addMarker(markerOptions)

    }

    private fun getAddress(currentLatLng: LatLng): String {
        val geocoder = Geocoder(this)
        val addresses: List<Address>?
        var address: Address? = null
        var addressText = ""

        try {
            addresses = geocoder.getFromLocation(currentLatLng.latitude, currentLatLng.longitude, 1)
            if (!addresses.isEmpty()) {
                address = addresses[0]
                addressText =
                    address.featureName + "," + address.subLocality + "," + address.adminArea + "" + address.countryName + "," + "," + address.postalCode
            }
        } catch (e: IOException) {
            Log.e("MapsActivity", e.localizedMessage)
        }
        //  Log.e("addressText","addressText"+addressText)
        return addressText
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        layoutChefDetails.visibility = View.VISIBLE
        txtCityChefDetails.text= PrefUtils.getCityname(this)
        initview()
        actionLister()

    }

    private fun actionLister() {

        fab.setOnClickListener {
            loadPlacePicker()
        }

        layoutReviewChef1.setOnClickListener {
            Log.e("Chef","chef")
            loadButtonUiChef(1)
        }
        layoutShareChef1.setOnClickListener {
            Log.e("Chef","chef")
            loadButtonUiChef(2)
        }
        layoutRate1.setOnClickListener {
            Log.e("Chef","chef")
            loadButtonUiChef(3)
            AddRateDialog(this)
        }
        layoutMenu1.setOnClickListener {
            Log.e("Chef","chef")
            loadButtonUiChef(4)
        }
        txtCityChefDetails.setOnClickListener {
            Log.e("Chef","chef")
            AddressActivity.launchActivity(this)
        }
        imgiconGps.setOnClickListener {

            MyAddressActivity.launchActivity(this)
        }
        FlBreakfast.setOnClickListener {
            MenuItemListactivity.launchActivity(this)
        }
        FlLunch.setOnClickListener {
            MenuItemListactivity.launchActivity(this)
        }
        FlDinner.setOnClickListener {
            MenuItemListactivity.launchActivity(this)
        }
        imgFilterChefDetails.setOnClickListener {
            FilterDialog(this)
        }

    }

    private fun initview() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map_chef) as SupportMapFragment
        mapFragment.getMapAsync(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createLocationRequest()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(p0: LocationResult) {
                super.onLocationResult(p0)

                lastLocation = p0.lastLocation
                placeMarkerOnMap(LatLng(lastLocation.latitude, lastLocation.longitude))
            }
        }
        val apikey: String = "AIzaSyBLugPwcvs_uo-ydAB3XGr90EsEwrrTIWE"
        Places.initialize(getApplicationContext(), apikey);

// Create a new Places client instance.

        val placesClient = Places.createClient(this)
        menu()
    }

    private fun menu() {
        mDrawerLayout = findViewById(R.id.drawer_layout)

        imgIconChefMenu.setOnClickListener {
            Log.e("Click", "click")
            if (!mDrawerLayout.isDrawerOpen(GravityCompat.START)) mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header = navigationView.getHeaderView(0)

        val headerMyProfile: RelativeLayout = header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder: LinearLayout = header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews: LinearLayout = header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney: LinearLayout = header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                    DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)

                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }
    }

    private fun loadPlacePicker() {
         val builder = PlacePicker.IntentBuilder()
        try {
            Log.e("Load","Load")
            startActivityForResult(builder.build(this), PLACE_PICKER_REQUEST)

        } catch (e: GooglePlayServicesRepairableException) {
            e.printStackTrace()
        } catch (e: GooglePlayServicesNotAvailableException) {
            e.printStackTrace()
        }

    }

    private fun createLocationRequest() {
        locationRequest = LocationRequest()
        // 2
        locationRequest.interval = 10000
        // 3
        locationRequest.fastestInterval = 5000
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)

        // 4
        val client = LocationServices.getSettingsClient(this)
        val task = client.checkLocationSettings(builder.build())

        // 5
        task.addOnSuccessListener {
            locationUpdateState = true
            startLocationUpdates()
        }
        task.addOnFailureListener { e ->
            // 6
            if (e is ResolvableApiException) {
                try {
                    // Show the dialog by calling startResolutionForResult(),
                    // and check the result in onActivityResult().
                    e.startResolutionForResult(this, REQUEST_CHECK_SETTINGS)
                } catch (sendEx: IntentSender.SendIntentException) {
                    // Ignore the error.
                }
            }
        }
    }

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }
        //2
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null /* Looper */)
    }

    private fun loadButtonUiChef(position: Int) {
        when (position) {
            1 -> {
                txtReviewsChefName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                imgReviewsChef1.setImageResource(R.drawable.icon_review_selected)
                layoutShareChef1.setOnClickListener {
                    imgShare1.setImageResource(R.drawable.icon_share_selected)
                    txtShareName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))


                }
                layoutRate1.setOnClickListener {
                    imgRate1.setImageResource(R.drawable.icon_rate_selected)
                    txtRateName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))

                }
                layoutMenu1.setOnClickListener {
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))

                }

            }
            2 -> {
                imgShare1.setImageResource(R.drawable.icon_share_selected)
                txtShareName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                imgReviewsChef1.setImageResource(R.drawable.icon_review)
                txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))
                imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                imgRate1.setImageResource(R.drawable.icon_rate)
                txtRateName1.setTextColor(getResources().getColor(R.color.black))
                layoutReviewChef1.setOnClickListener {
                    imgReviewsChef1.setImageResource(R.drawable.icon_review_selected)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))

                }
                layoutRate1.setOnClickListener {
                    imgRate1.setImageResource(R.drawable.icon_rate_selected)
                    txtRateName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))

                }
                layoutMenu1.setOnClickListener {
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))


                }
            }
            3 -> {
                imgRate1.setImageResource(R.drawable.icon_rate_selected)
                txtRateName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                layoutReviewChef1.setOnClickListener {
                    imgReviewsChef1.setImageResource(R.drawable.icon_review_selected)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))

                }
                layoutShareChef1.setOnClickListener {
                    imgShare1.setImageResource(R.drawable.icon_share_selected)
                    txtShareName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))


                }
                layoutMenu1.setOnClickListener {
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))

                }
            }
            4 -> {
                imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail_selected)
                txtMenuName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                layoutShareChef1.setOnClickListener {
                    imgShare1.setImageResource(R.drawable.icon_share_selected)
                    txtShareName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))


                }
                layoutRate1.setOnClickListener {
                    imgRate1.setImageResource(R.drawable.icon_rate_selected)
                    txtRateName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgReviewsChef1.setImageResource(R.drawable.icon_review)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.black))


                }
                layoutReviewChef1.setOnClickListener {
                    imgReviewsChef1.setImageResource(R.drawable.icon_review_selected)
                    txtReviewsChefName1.setTextColor(getResources().getColor(R.color.colorsplacebackground))
                    imgShare1.setImageResource(R.drawable.icon_share)
                    txtShareName1.setTextColor(getResources().getColor(R.color.black))
                    imgMenu1.setImageResource(R.drawable.icon_menu_chef_detail)
                    txtMenuName1.setTextColor(getResources().getColor(R.color.black))
                    imgRate1.setImageResource(R.drawable.icon_rate)
                    txtRateName1.setTextColor(getResources().getColor(R.color.black))

                }
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            if (resultCode == Activity.RESULT_OK) {
                locationUpdateState = true
                startLocationUpdates()
            }
        }
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                val place = PlacePicker.getPlace(this, data)
                var addressText = place.name.toString()
                addressText += "\n" + place.address.toString()

                placeMarkerOnMap(place.latLng)
            }
        }
    }

    // 2
    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    // 3
    public override fun onResume() {
        super.onResume()
        if (!locationUpdateState) {
            startLocationUpdates()
        }
    }
}