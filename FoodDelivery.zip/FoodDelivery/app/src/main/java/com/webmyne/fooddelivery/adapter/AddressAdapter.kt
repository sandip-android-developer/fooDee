package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.model.User_Address
import kotlinx.android.synthetic.main.item_address.view.*

class AddressAdapter(
    val context: Context,
    val useradress: List<User_Address>
): RecyclerView.Adapter<AddressAdapter.AllUserVH>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddressAdapter.AllUserVH {
        return AddressAdapter.AllUserVH(
            LayoutInflater.from(context).inflate(
                R.layout.item_address,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return useradress.size

    }

    override fun onBindViewHolder(holder:AllUserVH, position: Int) {
      holder.itemView.txtaddress.text=useradress.get(position).adressType+"\n"+" ,"+useradress.get(position).address1+"," +useradress.get(position).city+"," +useradress.get(position).country+"," +useradress.get(position).zipcode


    }

    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {

    }
}