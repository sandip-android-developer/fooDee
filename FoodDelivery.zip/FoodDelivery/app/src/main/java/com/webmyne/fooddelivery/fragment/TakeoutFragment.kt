package com.webmyne.fooddelivery.fragment

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.HomeAdapter
import com.webmyne.fooddelivery.model.HomeDetails
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.main_recycler.*
import kotlinx.android.synthetic.main.toolbar_home.*

@SuppressLint("ValidFragment")
class TakeoutFragment(var activity: BaseActivity) :BaseFragment(){
    var item:List<HomeDetails> = ArrayList()
    var itemCount:Int=0
    companion object{
        fun getInstance(baseActivity: BaseActivity): FavoritesFragments {
            return FavoritesFragments(baseActivity)
        }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.main_recycler, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initview()
        actionListner()

    }

    private fun actionListner() {
    }

    private fun initview() {
        var item= ArrayList<HomeDetails>()
        recycyclerView.layoutManager= LinearLayoutManager(context)
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        //txtitemCount.text=itemCount.toString()
        val adapter = HomeAdapter(activity,item,object:HomeAdapter.onitemCount{
            override fun onitemcount(count: Int) {
                itemCount=count
            }

        })
        recycyclerView.adapter=adapter

    }
}