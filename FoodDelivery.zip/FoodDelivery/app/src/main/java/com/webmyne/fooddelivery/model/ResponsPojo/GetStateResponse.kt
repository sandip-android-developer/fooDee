package com.webmyne.fooddelivery.model.ResponsPojo

open  class GetStateResponse{
    var result: List<ResultX> = ArrayList()

}
