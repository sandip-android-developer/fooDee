package com.webmyne.fooddelivery.model

class HomeScreenResponse {
}