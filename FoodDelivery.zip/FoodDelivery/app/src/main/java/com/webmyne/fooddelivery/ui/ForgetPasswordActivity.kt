package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import kotlinx.android.synthetic.main.activity_forget_password.*

class ForgetPasswordActivity: BaseActivity() {
    val db: DatabaseHelper = DatabaseHelper(this)
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, ForgetPasswordActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)
        initView()
        actionListner()
    }

    private fun actionListner() {

    }

    private fun initView() {
        txtGetPass.setOnClickListener {
            if (!db.checkUser(edtForgetEmail.text.toString().trim()))
            {
                Toast.makeText(this,"Email Id Is not Valid", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            else
            {
                var list:List<String> = ArrayList()
                list=db.getUserData(edtForgetEmail.text.toString().trim())
                Log.e("Address","Address"+list)
                txtFPassword.text=list.get(0)
            }
        }


    }
}