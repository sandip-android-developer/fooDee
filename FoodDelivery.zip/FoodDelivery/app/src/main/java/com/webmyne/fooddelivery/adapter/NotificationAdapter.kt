package com.webmyne.fooddelivery.adapter

import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.address_list.view.*
import kotlinx.android.synthetic.main.item_faq.view.*

class NotificationAdapter(
    val context: BaseActivity
): RecyclerView.Adapter<NotificationAdapter.AllUserVH>() {
    var rowIndex:Int = -1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AllUserVH {
        return AllUserVH(
            LayoutInflater.from(context).inflate(
                R.layout.item_notifation,
                parent,
                false
            )
        )
    }



    override fun onBindViewHolder(holder:AllUserVH, position: Int) {

   //  holder.itemView.txtaddress.text=useradress.get(position).adressType+"\n"+" ,"+useradress.get(position).address1+"," +useradress.get(position).city+"," +useradress.get(position).country+"," +useradress.get(position).zipcode



    }
    override fun getItemCount(): Int {
        return 10

    }
    class AllUserVH(view: View): RecyclerView.ViewHolder(view) {




    }
}