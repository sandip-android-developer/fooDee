package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.Toolbar
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.custome.FilterDialog
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import com.yarolegovich.slidingrootnav.SlidingRootNav
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder
import kotlinx.android.synthetic.main.activity_dashbord.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.toolbar_home.*

class DashboardActivity: BaseActivity() {
    private lateinit var mDrawerLayout: DrawerLayout
    private var slidingRootNav: SlidingRootNav? = null
    private var toolbar: Toolbar? = null
    var header: LinearLayout? = null
    var CountItem = 0;
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, DashboardActivity::class.java, true, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)
        layoutdash.visibility = View.VISIBLE
        initview()
        actionListner()


    }

    private fun actionListner() {
        txtCity.text=PrefUtils.getCityname(this)
        loadButtonUi(1)
        txtCity.setOnClickListener {
            AddressActivity.launchActivity(this)
        }
        imgiconGps.setOnClickListener {
            MyAddressActivity.launchActivity(this)
        }
        layoutFavorite.setOnClickListener {
            Functions.hideKeyPad(DashboardActivity@ this, it)
            loadButtonUi(1)
        }

        layoutDelivery.setOnClickListener {
            Functions.hideKeyPad(DashboardActivity@ this, it)
            loadButtonUi(2)
        }

        latoutTakeout.setOnClickListener {
            Functions.hideKeyPad(DashboardActivity@ this, it)
            loadButtonUi(3)
        }

        layoutDinein.setOnClickListener {
            Functions.hideKeyPad(DashboardActivity@ this, it)
            loadButtonUi(4)
        }
    imgIconCart.setOnClickListener {
            BasketActivity.launchActivity(this)
        }
        imgIconFilter.setOnClickListener {
            FilterDialog(this)
        }
    }



    private fun initview() {

        mDrawerLayout = findViewById(R.id.drawer_layout)

        imgIconMenu.setOnClickListener {

            if (!mDrawerLayout.isDrawerOpen(GravityCompat.START)) mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header = navigationView.getHeaderView(0)

        val headerMyProfile: RelativeLayout = header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder: LinearLayout = header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews: LinearLayout = header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney: LinearLayout = header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                    DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)

                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }
    }
    private fun initDrawer(savedInstanceState: Bundle?) {
            slidingRootNav = SlidingRootNavBuilder(this)
                .withToolbarMenuToggle(toolbar)
                .withRootViewScale(0.7f)
                //  .withMenuOpened(false)
                .withContentClickableWhenMenuOpened(true)
                .withSavedState(savedInstanceState)
                .withMenuLayout(R.layout.toolbar_home)
                .inject()

        }
}

