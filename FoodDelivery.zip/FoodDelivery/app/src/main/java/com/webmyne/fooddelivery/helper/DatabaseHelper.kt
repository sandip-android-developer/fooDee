package com.webmyne.fooddelivery.helper

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.webmyne.fooddelivery.model.HomeDetails
import com.webmyne.fooddelivery.model.User
import com.webmyne.fooddelivery.model.User_Address
import com.webmyne.fooddelivery.model.User_PaymentInfo


class DatabaseHelper(context: Context): SQLiteOpenHelper(context,DATABASE_NAME,null,DATABASE_VERSION) {

    companion object {
        private val DATABASE_VERSION = 2
        private val DATABASE_NAME = "UserManager.db"

        //Table-Name
        private val TABLE_USER = "user"
        private val TABLE_ADDRESS = "table_address"
        private val TABLE_PAYMENTINFO = "user_payment"

        //Table User Column
        private val COLUMN_USER_ID = "user_id"
        private val COLUMN_USER_NAME = "user_name"
        private val COLUMN_USER_EMAIL = "user_email"
        private val COLUMN_USER_Mobile = "user_mobile"
        private val COLUMN_USER_PASSWORD = "user_password"
        private val COLUMN_USER_ADDRESS = "user_address"
        private val COLUMN_USER_PAYMENTINFO = "user_payment"
        private val COLUMN_USER_IMAGE = "user_image"

        //Table Address Column
        private val COLUMN_ADDRESS_ADDRESS_TYPE = "adress_type"
        private val COLUMN_ADDRESS_SHORT_ADDRESS = "address_short"
        private val COLUMN_ADDRESS_CITY = "address_city"
        private val COLUMN_ADDRESS_STATE = "address_state"
        private val COLUMN_ADDRESS_COUNTRY = "address_country"
        private val COLUMN_ADDRESS_ZIPCODE = "address_zipcode"

        //Table PAYMENTINFO Column
        private val COLUMN_PAYMENT_CARD_TYPE = "payment_card_type"
        private val COLUMN_PAYMENT_HOLDERNAME = "payment_card_holdernmae"
        private val COLUMN_PAYMENT_CARDNUMBER = "payment_cardnumber"
        private val COLUMN_PAYMENT_EXPIRYMONTH = "payment_expirymonth"
        private val COLUMN_PAYMENT_EXPIRYYEAR = "payment_expiryyear"
    }

   //val  DATABASE_ALTER_TEAM_1 = "ALTER TABLE "+ COLUMN_USER_Mobile + " string;"
    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_USER_TABLE = ("CREATE TABLE IF NOT EXISTS " + TABLE_USER + "(" + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NAME + " TEXT," + COLUMN_USER_EMAIL + " TEXT," + COLUMN_USER_Mobile + " TEXT," + COLUMN_USER_PASSWORD + " TEXT," + COLUMN_USER_ADDRESS + " TEXT," + COLUMN_USER_PAYMENTINFO + " TEXT" + COLUMN_USER_IMAGE + " BLOB" + ")")

        val CREATE_ADDRESS_TABLE = ("CREATE TABLE IF NOT EXISTS " + TABLE_ADDRESS + "(" + COLUMN_USER_ID + " INTEGER,"
                + COLUMN_ADDRESS_ADDRESS_TYPE + " TEXT," + COLUMN_ADDRESS_SHORT_ADDRESS + " TEXT," + COLUMN_ADDRESS_CITY + " TEXT," + COLUMN_ADDRESS_STATE + " TEXT," + COLUMN_ADDRESS_COUNTRY + " TEXT," + COLUMN_ADDRESS_ZIPCODE + " TEXT" + ")")


        val CREATE_PAYMENTINFO_TABLE = ("CREATE TABLE IF NOT EXISTS " + TABLE_PAYMENTINFO + "(" + COLUMN_USER_ID + " INTEGER,"
                + COLUMN_PAYMENT_CARD_TYPE + " TEXT," + COLUMN_PAYMENT_HOLDERNAME + " TEXT," + COLUMN_PAYMENT_CARDNUMBER + " TEXT," + COLUMN_PAYMENT_EXPIRYMONTH + " TEXT," + COLUMN_PAYMENT_EXPIRYYEAR + " TEXT" + ")")


        db?.execSQL(CREATE_USER_TABLE)
        db?.execSQL(CREATE_ADDRESS_TABLE)
        db?.execSQL(CREATE_PAYMENTINFO_TABLE)


    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

        /*if (oldVersion < 3) {
            db!!.execSQL(DATABASE_ALTER_TEAM_1);
        }*/
       db!!.execSQL("DROP TABLE IF EXISTS " + TABLE_USER)
        db!!.execSQL("DROP TABLE IF EXISTS " + TABLE_ADDRESS)
        db!!.execSQL("DROP TABLE IF EXISTS " + TABLE_PAYMENTINFO)
        onCreate(db)
    }

    fun addUser(user: User):Long{
        val db=this.writableDatabase
        val values=ContentValues()
        values.put(COLUMN_USER_NAME,user.username)
        values.put(COLUMN_USER_EMAIL,user.useremail)
        values.put(COLUMN_USER_Mobile,user.usermobile)
        values.put(COLUMN_USER_PASSWORD,user.userpassword)
        values.put(COLUMN_USER_IMAGE,user.userImage)
        val id = db.insertWithOnConflict(TABLE_USER, null, values, SQLiteDatabase.CONFLICT_IGNORE)

        val valuesAddress = ContentValues()
      /*  valuesAddress.put(COLUMN_USER_ID, id);
        valuesAddress.put(COLUMN_ADDRESS_ADDRESS_TYPE, user.useradress!!.get(0).adressType);
        valuesAddress.put(COLUMN_ADDRESS_SHORT_ADDRESS,  user.useradress!!.get(0).address1);
        valuesAddress.put(COLUMN_ADDRESS_CITY,  user.useradress!!.get(0).city);
        valuesAddress.put(COLUMN_ADDRESS_STATE, user.useradress!!.get(0).state);
        valuesAddress.put(COLUMN_ADDRESS_COUNTRY,  user.useradress!!.get(0).country);
        valuesAddress.put(COLUMN_ADDRESS_ZIPCODE,  user.useradress!!.get(0).zipcode);*/
        db.insert(TABLE_ADDRESS, null, valuesAddress)

        //adding user city in users_city table
       val  valuesPaymentInfo =ContentValues()
       /* valuesPaymentInfo.put(COLUMN_USER_ID, id);
        valuesPaymentInfo.put(COLUMN_PAYMENT_CARD_TYPE, user.userPayment!!.get(0).cardType);
        valuesPaymentInfo.put(COLUMN_PAYMENT_HOLDERNAME, user.userPayment!!.get(0).holderName);
        valuesPaymentInfo.put(COLUMN_PAYMENT_CARDNUMBER, user.userPayment!!.get(0).cardNumber);
        valuesPaymentInfo.put(COLUMN_PAYMENT_EXPIRYMONTH, user.userPayment!!.get(0).cardexpiryMonth);
        valuesPaymentInfo.put(COLUMN_PAYMENT_EXPIRYYEAR, user.userPayment!!.get(0).cardExpiryYear);*/
        db.insert(TABLE_PAYMENTINFO, null, valuesPaymentInfo)
        db.close()
        return id
    }
    fun addAddress(id:Int,userAddress: User_Address){
        val db=this.writableDatabase
        val valuesAddress = ContentValues()
        valuesAddress.put(COLUMN_USER_ID, id)
        valuesAddress.put(COLUMN_ADDRESS_ADDRESS_TYPE, userAddress.adressType);
        valuesAddress.put(COLUMN_ADDRESS_SHORT_ADDRESS,userAddress.address1);
        valuesAddress.put(COLUMN_ADDRESS_CITY,userAddress.city);
        valuesAddress.put(COLUMN_ADDRESS_STATE,userAddress.state);
        valuesAddress.put(COLUMN_ADDRESS_COUNTRY,userAddress.country);
        valuesAddress.put(COLUMN_ADDRESS_ZIPCODE,userAddress.zipcode);
        db.insert(TABLE_ADDRESS, null, valuesAddress)
    }
    fun addPaymentInfo(id:Int,userPaymentinfo: User_PaymentInfo){
        val db=this.writableDatabase
        val valuesAddress = ContentValues()

        valuesAddress.put(COLUMN_USER_ID, id)
        valuesAddress.put(COLUMN_PAYMENT_CARD_TYPE, userPaymentinfo.cardType);
        valuesAddress.put(COLUMN_PAYMENT_HOLDERNAME,userPaymentinfo.holderName);
        valuesAddress.put(COLUMN_PAYMENT_CARDNUMBER,userPaymentinfo.cardNumber);
        valuesAddress.put(COLUMN_PAYMENT_EXPIRYMONTH,userPaymentinfo.cardexpiryMonth);
        valuesAddress.put(COLUMN_PAYMENT_EXPIRYYEAR,userPaymentinfo.cardExpiryYear);
        db.insert(TABLE_PAYMENTINFO, null, valuesAddress )

    }



    fun viewUser():List<User>{
        val userList= ArrayList<User>()

        val selectQuery="SELECT  * FROM $TABLE_USER"

        val db = this.readableDatabase
        var cursor: Cursor?=null
        try{
            cursor = db.rawQuery(selectQuery, null)
        }catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        var userId: Int
        var userpassword: String
        var userName: String
        var userMobile: String
        var userEmail: String
        var userImage: String

        var userAddress: User_Address?=null
        var userPaymentinfo: User_PaymentInfo?=null

        var addressId: Int
        var adressType: String
        var address1: String
        var city: String
        var state: String
        var country: String
        var zipcode: String

         var paymentId: Int
         var cardType: String
         var holderName: String
         var cardexpiryMonth: String
         var cardExpiryYear: String
         var cardNumber: String
        var fulladdress= ArrayList<User_Address>()
        var item= ArrayList<User_PaymentInfo>()

        if (cursor.moveToFirst()){
            do {
                userId = cursor!!.getInt(cursor!!.getColumnIndex(COLUMN_USER_ID))
                userName = cursor!!.getString(cursor!!.getColumnIndex(COLUMN_USER_NAME))
                userEmail = cursor!!.getString(cursor!!.getColumnIndex(COLUMN_USER_EMAIL))
                userMobile = cursor!!.getString(cursor!!.getColumnIndex(COLUMN_USER_Mobile))
                userpassword = cursor!!.getString(cursor!!.getColumnIndex(COLUMN_USER_PASSWORD))
                userImage = cursor!!.getString(cursor!!.getColumnIndex(COLUMN_USER_IMAGE))

                val selectQuery="SELECT  * FROM $TABLE_ADDRESS"
                var cursor1: Cursor?=null
                try{
                    cursor1 = db.rawQuery(selectQuery, null)
                }catch (e: SQLiteException) {
                    db.execSQL(selectQuery)
                    return ArrayList()
                }
                var address=User_Address()
                if (cursor1.moveToFirst()){
                    do {
                        addressId = cursor1!!.getInt(cursor1!!.getColumnIndex(COLUMN_USER_ID))
                        adressType = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_ADDRESS_TYPE))
                        address1 = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_SHORT_ADDRESS))
                        city = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_CITY))
                        state = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_STATE))
                        country = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_COUNTRY))
                        zipcode = cursor1!!.getString(cursor1!!.getColumnIndex(COLUMN_ADDRESS_ZIPCODE))
                        address!!.userid=addressId
                        address!!.adressType=adressType
                        address!!.address1=address1
                        address!!.city=city
                        address!!.state=state
                        address!!.country=country
                        address!!.zipcode=zipcode
                    }while (cursor1!!.moveToNext())


                    fulladdress.add(address)
                  /*address=User_Address(addressId,adressType,address1,city,state,country,zipcode)*/
                }
                var pay=User_PaymentInfo()
                val selectQuery1="SELECT  * FROM $TABLE_PAYMENTINFO"
                var cursor2: Cursor?=null
                try{
                    cursor2 = db.rawQuery(selectQuery1, null)
                }catch (e: SQLiteException) {
                    db.execSQL(selectQuery)
                    return ArrayList()
                }
                if (cursor2!!.moveToFirst()){
                    do {
                        paymentId = cursor2!!.getInt(cursor2!!.getColumnIndex(COLUMN_USER_ID))
                        cardType = cursor2!!.getString(cursor2!!.getColumnIndex(COLUMN_PAYMENT_CARD_TYPE))
                        holderName = cursor2!!.getString(cursor2!!.getColumnIndex(COLUMN_PAYMENT_HOLDERNAME))
                        cardexpiryMonth = cursor2!!.getString(cursor2!!.getColumnIndex(COLUMN_PAYMENT_EXPIRYMONTH))
                        cardExpiryYear = cursor2!!.getString(cursor2!!.getColumnIndex(COLUMN_PAYMENT_EXPIRYYEAR))
                        cardNumber = cursor2!!.getString(cursor2!!.getColumnIndex(COLUMN_PAYMENT_CARDNUMBER))

                        pay!!.userid=paymentId
                        pay!!.cardType=cardType
                        pay!!.holderName=holderName
                        pay.cardexpiryMonth=cardexpiryMonth
                        pay.cardExpiryYear=cardExpiryYear
                        pay.cardNumber=cardNumber
                        item.add(pay)
                    }while (cursor2!!.moveToNext())

            }



                val  user= User(userId,userName,userEmail,userMobile,userpassword,fulladdress,item,userImage)
                userList.add(user)
            } while (cursor.moveToNext())
        }
        return userList
    }
    fun updateUser(user: User):Int{
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUMN_USER_ID, user.userid)
        contentValues.put(COLUMN_USER_NAME,user.username) // EmpModelClass Name
        contentValues.put(COLUMN_USER_EMAIL,user.useremail)
        contentValues.put(COLUMN_USER_Mobile,user.usermobile)
        contentValues.put(COLUMN_USER_PASSWORD,user.userpassword)

        val success = db.update(TABLE_USER, contentValues,"id="+user.userid,null)

        db.close() // Closing database connection
        return success
    }

    fun deleteUser(user: User):Int{
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_USER_ID, user.userid)
        val success = db.delete(TABLE_USER,"id="+user.userid,null)

        db.close() // Closing database connection
        return success
    }
    fun checkUser(email:String):Boolean
    {
        val columns = arrayOf(COLUMN_USER_ID)
        val db = this.readableDatabase
        val selection = "$COLUMN_USER_EMAIL=?"
        val selectionArgs = arrayOf(email)
        val cursor = db.query(
            TABLE_USER, //Table to query
            columns, //columns to return
            selection, //columns for the WHERE clause
            selectionArgs, //filter by row groups
            null, null, null
        )//The values for the WHERE clause
        //group the rows
        val cursorCount = cursor.count
        cursor.close()
        db.close()
        return if (cursorCount > 0) {
            return true
        } else
            return false
    }
    fun checkUser(email:String,password:String):Boolean{
        val columns = arrayOf(COLUMN_USER_ID)
        val db = this.readableDatabase
        val selection = "$COLUMN_USER_EMAIL=?AND $COLUMN_USER_PASSWORD=?"
        val selectionArgs = arrayOf(email, password)
        val cursor = db.query(
            TABLE_USER, //Table to query
            columns, //columns to return
            selection, //columns for the WHERE clause
            selectionArgs, //filter by row groups
            null, null, null
        )//The values for the WHERE clause
        //group the rows
        val cursorCount = cursor.count
        cursor.close()
        db.close()
        return if (cursorCount > 0) {
            return true
        } else return false

    }
    fun getUserData(email:String):List<String>{
        val db = this.readableDatabase
        var c:Cursor
        var list=ArrayList<String>()
        c = db.rawQuery("SELECT * FROM $TABLE_USER where $COLUMN_USER_EMAIL = '$email'", null)
        var pass: String = ""
        var name: String = ""
        var phn: String = ""
        if (c.moveToFirst()) {
            do {
                list.add(c.getString(c.getColumnIndex(COLUMN_USER_PASSWORD)))
                list.add(c.getString(c.getColumnIndex(COLUMN_USER_NAME)))
                list.add(c.getString(c.getColumnIndex(COLUMN_USER_Mobile)))
                list.add(c.getString(c.getColumnIndex(COLUMN_USER_ADDRESS)))
                list.add(c.getString(c.getColumnIndex(COLUMN_USER_PAYMENTINFO)))


            } while (c.moveToNext())
        }
        return list
    }
    fun updateUserData(password:String,email:String):String{
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(COLUMN_USER_PASSWORD, password)
        db.update(TABLE_USER, cv, COLUMN_USER_EMAIL + "= '$email'", null)
        return password

    }

}