package com.webmyne.fooddelivery.fragment

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.HomeAdapter
import com.webmyne.fooddelivery.model.HomeDetails
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.activity_city.*
import kotlinx.android.synthetic.main.home_item_list.*
import kotlinx.android.synthetic.main.main_recycler.*
import kotlinx.android.synthetic.main.toolbar_home.*
import java.util.*
import kotlin.collections.ArrayList

@SuppressLint("ValidFragment")
class DineinFragment  constructor(var activity: BaseActivity) :BaseFragment(){
    var item:List<HomeDetails> = ArrayList()
    var itemCount:Int=0
    companion object{
        fun getInstance(baseActivity: BaseActivity): FavoritesFragments {
            return FavoritesFragments(baseActivity)
        }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.main_recycler, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initview()
        actionListner()

    }

    private fun actionListner() {
        //val img = imgHomeItemImage
        var CountItem = 0
        val countMinus = imgHomeItemLeftArrow
        val countPlus = imgHomeItemRightArrow
        val Count=txtHomeNumberOfItem
        val chefImage=imgHomeChefImage
        /*  chefImage.setOnClickListener {
              val intent = Intent(activity, BasketActivity::class.java)
              startActivity(intent)
          }*/
        /* countMinus.setOnClickListener(object : View.OnClickListener {
             override fun onClick(v: View?) {
                 if (CountItem > 0) {
                     CountItem--

                     Count.text = "$CountItem"
                 }
             }

         })
         countPlus.setOnClickListener(object : View.OnClickListener {
             override fun onClick(v: View?) {
                 CountItem++
                 Count.text = "$CountItem"
             }

         })*/
        /* img.setOnClickListener {
             val intent = Intent(activity, ChefDetailsActivity::class.java)
             startActivity(intent)
         }*/

    }

    private fun initview() {
        var item= ArrayList<HomeDetails>()
        recycyclerView.layoutManager= LinearLayoutManager(context)
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
        item.add(HomeDetails("https://ibb.co/0VsBnbL","Donut","powa"))
       //txtitemCount.text=itemCount.toString()
        Log.e("Data","Data"+itemCount.toString())
        val adapter = HomeAdapter(activity,item,object :HomeAdapter.onitemCount{
            override fun onitemcount(count: Int) {
                itemCount=count
            }

        })
        recycyclerView.adapter=adapter

    }
}