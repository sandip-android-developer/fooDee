package com.webmyne.fooddelivery.model
import android.media.Image
import java.io.Serializable
class SaveCardDetails(
    val CardNumber:String,
    val Image:Int
):Serializable