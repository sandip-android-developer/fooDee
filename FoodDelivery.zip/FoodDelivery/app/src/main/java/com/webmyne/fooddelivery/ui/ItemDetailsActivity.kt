package com.webmyne.fooddelivery.ui

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.adapter.ChefReviewsAdapter
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import com.yarolegovich.slidingrootnav.SlidingRootNav
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder
import kotlinx.android.synthetic.main.activity_item_details.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.toolbar_about_chef.*
import kotlinx.android.synthetic.main.toolbar_item.*
import kotlinx.android.synthetic.main.toolbar_item.imgiconGps
import kotlinx.android.synthetic.main.toolbar_item.txtCity

class ItemDetailsActivity: BaseActivity() {
    private lateinit var mDrawerLayout: DrawerLayout
    private var toolbar: Toolbar? = null
    private var slidingRootNav: SlidingRootNav? = null
    var CountItem=0;
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, ItemDetailsActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
     setSupportActionBar(toolbar)
        layoutItemDetailsActivity.visibility= View.VISIBLE
        rvItemReviews.layoutManager=LinearLayoutManager(this)
        rvItemReviews.adapter=ChefReviewsAdapter(this)
        btnReviews.text="Reviews "+"("+ PrefUtils.getReviewsCount(this).toString() +" )"
    initview()
    actionListion()


    }

    private fun actionListion() {
        var Count: TextView =findViewById(R.id.txtCountNumberOfItem)
        imgChefImage.setOnClickListener {
            AboutChefActivity.launchActivity(this)
        }

        btnDetails.setBackgroundResource(R.drawable.tab_review_select)
        btnDetails.setTextColor(getResources().getColor(R.color.white))
        btnDetails.setOnClickListener {

            loadButtonUi1(1)

        }
        btnReviews.setOnClickListener {
            btnDetails.setBackgroundResource(R.color.bgapp)
            btnDetails.setTextColor(getResources().getColor(R.color.black))
            loadButtonUi1(2)

        }
        var countPlus:ImageView=findViewById(R.id.imgHomeItemRightArrow)
        var countMinus:ImageView=findViewById(R.id.imgHomeItemLeftArrow)
        countMinus.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {

                if(CountItem>0) {
                    CountItem--
                    Count.text = "$CountItem"
                }
            }

        })
        countPlus.setOnClickListener(object: View.OnClickListener{
            override fun onClick(v: View?) {
                CountItem++
                Count.text="$CountItem"
            }

        })
        txtCity.setOnClickListener {
            AddressActivity.launchActivity(this)
        }
        imgiconGps.setOnClickListener {
            MyAddressActivity.launchActivity(this)
        }

    }

    fun loadButtonUi1(position: Int) {
        when (position) {
            1 -> {
                btnDetails.setBackgroundResource(R.drawable.tab_review_select)
                btnDetails.setTextColor(getResources().getColor(R.color.white))
               btnReviews.setOnClickListener {
                    btnDetails.setBackgroundResource(R.color.bgapp)
                    btnDetails.setTextColor(getResources().getColor(R.color.black))
                    loadButtonUi(2)

                }
            }
            2 -> {

                btnReviews.setBackgroundResource(R.drawable.tab_review_select)
                btnReviews.setTextColor(getResources().getColor(R.color.white))
                txtDetails.visibility = View.INVISIBLE
                rvItemReviews.visibility = View.VISIBLE
                btnDetails.setOnClickListener {
                    btnReviews.setBackgroundResource(R.color.bgapp)
                    btnReviews.setTextColor(getResources().getColor(R.color.black))
                    btnDetails.setBackgroundResource(R.drawable.tab_review_select)
                    btnDetails.setTextColor(getResources().getColor(R.color.white))
                    rvItemReviews.visibility = View.INVISIBLE
                    txtDetails.visibility = View.VISIBLE
                    loadButtonUi(1)

                }
            }
        }
    }

    private fun initview() {

        mDrawerLayout = findViewById(R.id.drawer_layout)

        imgIconItemMenu.setOnClickListener {
            Log.e("Click","click")
            if (!mDrawerLayout.isDrawerOpen(GravityCompat.START)) mDrawerLayout.openDrawer(Gravity.START);
            else mDrawerLayout.closeDrawer(Gravity.END);
        }
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val header = navigationView.getHeaderView(0)

        val headerMyProfile: RelativeLayout = header.findViewById(R.id.rlProfile)
        headerMyProfile.setOnClickListener {
            EditProfileActivity.launchActivity(this)
        }

        val headerMyOrder: LinearLayout = header.findViewById(R.id.layoutMyOrder)

        headerMyOrder.setOnClickListener {
            MyOrderActivity.launchActivity(this)
        }
        val headerReviews: LinearLayout = header.findViewById(R.id.layoutMoney)

        headerReviews.setOnClickListener {

            ModakMoneyActivity.launchActivity(this)
        }
        val headerModakMoney: LinearLayout = header.findViewById(R.id.layoutReview)
        headerModakMoney.setOnClickListener {
            ReviewActivity.launchActivity(this)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            menuItem.isChecked = true

            mDrawerLayout.closeDrawers()
            when (menuItem.itemId) {
                R.id.navHome -> {
                    DashboardActivity.launchActivity(this)
                }
                R.id.navMyProfile -> {
                    MyProfileActivity.launchActivity(this)

                }
                R.id.navMyAdress -> {
                    MyAddressActivity.launchActivity(this)
                }
                R.id.navPaymentInfo -> {
                    CardActivity.launchActivity(this)
                }
                R.id.navNotifations -> {
                    NotificationActivity.launchActivity(this)
                }
                R.id.navFreeMeals -> {
                    BasketActivity.launchActivity(this)
                }
                R.id.navSetting -> {
                    SettingActivity.launchActivity(this)
                }
                R.id.navHelp -> {
                    HelpActivity.launchActivity(this)
                }
                R.id.navLogOut -> {
                    Functions.logoutDialog(this)
                }
            }
            true
        }


    }
    private fun initDrawer(savedInstanceState: Bundle?) {
        slidingRootNav = SlidingRootNavBuilder(this)
            .withToolbarMenuToggle(toolbar)
            .withRootViewScale(0.7f)
            //  .withMenuOpened(false)
            .withContentClickableWhenMenuOpened(true)
            .withSavedState(savedInstanceState)
            .withMenuLayout(R.layout.toolbar_home)
            .inject()

    }
}


