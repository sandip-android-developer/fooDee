package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.os.CountDownTimer
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils

class SplashActivity: BaseActivity() {
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()

    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, SplashActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        navigateToLogin()

    }

    private fun navigateToLogin() {
        val longestDelay:Long=1200
        val longestDuration:Long=3000
        var oneTouchTimer = object : CountDownTimer(longestDelay+longestDuration+500,1000){
            override fun onFinish() {
                if(PrefUtils.isUserLoggedIn(this@SplashActivity)){
                    Functions.fireIntent(this@SplashActivity,DashboardActivity::class.java,true,false)
                    finish()
                }else {
                    Functions.fireIntent(this@SplashActivity, LoginActivity::class.java, true, false)
                    finish()
                }
            }
            override fun onTick(millisUntilFinished: Long) {
            }

        }
        oneTouchTimer.start()

    }

}