package com.webmyne.fooddelivery.model

open  class User_PaymentInfo {
     var userid: Int=0
     var cardType: String=""
     var holderName: String=""
     var cardexpiryMonth: String=""
     var cardExpiryYear: String=""
     var cardNumber: String=""
}

