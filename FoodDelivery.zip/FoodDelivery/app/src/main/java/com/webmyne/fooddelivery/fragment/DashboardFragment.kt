package com.webmyne.fooddelivery.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.ui.BaseActivity
import kotlinx.android.synthetic.main.home_item_recycle.*

@SuppressLint("ValidFragment")
class DashboardFragment(baseActivity: BaseActivity) :BaseFragment(){
    companion object{
        fun getInstance(baseActivity: BaseActivity): DashboardFragment {
            return DashboardFragment(baseActivity)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.home_item_recycle, container, false)
        initView()

    }

    private fun initView() {
        rv_home.layoutManager=LinearLayoutManager(getBaseActivity())


    }




}