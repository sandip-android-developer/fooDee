package com.webmyne.fooddelivery.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.webmyne.fooddelivery.R
import kotlinx.android.synthetic.main.item_favorite.view.*


class MyFavoriteAdapter(
    val context: Context
) : RecyclerView.Adapter<MyFavoriteAdapter.ViewVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, position: Int):ViewVH {
        return ViewVH(LayoutInflater.from(context).inflate(R.layout.item_favorite, parent, false))
    }
    override fun onBindViewHolder(holder: ViewVH, position: Int) {

        holder.itemView.imgAddFavorite.setImageResource(R.drawable.bg_food_detail)


    }

    override fun getItemCount(): Int {
     return 10
    }


    class ViewVH (view: View) : RecyclerView.ViewHolder(view) {

    }
}
