package com.webmyne.fooddelivery.ui

import android.os.Bundle
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.analytics.FirebaseAnalytics
import com.webmyne.fooddelivery.R
import com.webmyne.fooddelivery.helper.DatabaseHelper
import com.webmyne.fooddelivery.helper.Functions
import com.webmyne.fooddelivery.helper.PrefUtils
import kotlinx.android.synthetic.main.activity_basket.*
import kotlinx.android.synthetic.main.activity_forget_password.*

class BasketActivity: BaseActivity() {
    val db: DatabaseHelper = DatabaseHelper(this)
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    var bundle = Bundle()
    companion object {
        fun launchActivity(activity: BaseActivity?) {
            if (activity != null) {
                Functions.fireIntent(activity, BasketActivity::class.java, true, false)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.webmyne.fooddelivery.R.layout.activity_basket)
        initview()
        actionListner()

    }

    private fun actionListner() {
        txtSelectPayment.setOnClickListener {
            CardActivity.launchActivity(this)
        }
        imgbackBasket.setOnClickListener {
           onBackPressed()
        }

    }

    private fun initview() {
        var list:List<String> =  ArrayList()
        list=db.getUserData(PrefUtils.getUserEmail(this))
        Log.e("Address","Address"+list)
        val name = list.get(1)
        val separated = name.split(" ")
        edtFirstName.setText( separated[0])
       /* if (separated[1].equals(""))
        {
            edtFirstName.setText( " ")
        }
        else
        {
            edtFirstName.setText( separated[1])
        }*/

        edtEmailAddress.setText(PrefUtils.getUserEmail(this))
        edtPhoneNumebr.setText(list.get(2))
        Log.e("Address","Address0"+list.get(0))
        Log.e("Address","Address1"+list.get(1))
        Log.e("Address","Address2"+list.get(2))
        Log.e("Address","Address3"+list.get(3))
    }



}